import { RegisterValidators } from './register-validators';

describe('RegisterValidators', () => {
  it('should create an instance', () => {
    expect(new RegisterValidators()).toBeTruthy();
  });
});
