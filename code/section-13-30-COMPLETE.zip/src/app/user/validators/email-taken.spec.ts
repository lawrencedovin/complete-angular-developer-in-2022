import { EmailTaken } from './email-taken';

describe('EmailTaken', () => {
  it('should create an instance', () => {
    expect(new EmailTaken()).toBeTruthy();
  });
});
